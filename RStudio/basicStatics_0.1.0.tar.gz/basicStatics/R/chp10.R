animals <- read.csv('R/table10_1.csv')

child_data <- read.csv('R/table11_1.csv')
