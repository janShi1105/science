t_val <- numeric(10000)
